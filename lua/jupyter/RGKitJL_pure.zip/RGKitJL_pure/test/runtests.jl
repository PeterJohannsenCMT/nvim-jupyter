using Test
using RGKit
using RGKit.ClaeysMatrices
using RGKit.LinearAlgebraExtras
using RGKit.Common
using RGKit.Integration
using RGKit.Richardson

@testset "EBV residual and Jacobian" begin
    ε = [-1.0, -0.3, 0.1, 0.9]
    E = epsilon_matrix(ε)
    x = ground_occupations(ε, 2)
    g = 0.2
    r = similar(x)
    residual!(r, x, g, E)
    J = zeros(eltype(x), length(x), length(x))
    jacobian!(J, x, g, E)
    # Finite-difference check
    δ = 1e-30
    for k in eachindex(x)
        x2 = copy(x); x2[k] += δ
        r2 = similar(r); residual!(r2, x2, g, E)
        @test isapprox((r2 .- r)[k]/δ, J[k,k]; atol=1e-18)  # diagonal coarse check
    end
end

@testset "Solve at fixed g" begin
    ε = collect(range(-1, 1; length=8))
    rg = Solver(ε, 3)
    ok, it = solve!(rg; g=0.0)
    @test ok
    @test all(abs.(rg.x .- ground_occupations(ε, 3)) .< 1e-28)
end

@testset "Integrate along g" begin
    ε = collect(range(-1, 1; length=8))
    rg = Solver(ε, 3)
    gpath = collect(range(0.0, 0.5; length=10))
    integrate!(rg; gpath=gpath)
    # basic sanity: x in [0,1] approximately
    @test all((rg.x .>= -1e-6) .& (rg.x .<= 1+1e-6))
end
