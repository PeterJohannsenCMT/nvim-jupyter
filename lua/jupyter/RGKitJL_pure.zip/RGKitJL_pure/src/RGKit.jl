module RGKit
export setprecision!, MP, Parameters, Solver, solve!, integrate!,
       epsilon_matrix, residual!, jacobian!, matrix_element_c

using LinearAlgebra
using Logging
using Printf
using Random

const MP = BigFloat
setprecision!(bits::Integer) = setprecision(bits)

include("Common.jl")
include("LinearAlgebraExtras.jl")
include("ClaeysMatrices.jl")
include("Integration.jl")
include("Richardson.jl")

end # module
