module Common
export elementwise, tobig, int_from_indices, ground_occupations

using LinearAlgebra

const MP = BigFloat

elementwise(A::AbstractVector, B::AbstractVector) = A .* B
tobig(x) = MP(x)
tobig(xs::AbstractArray) = MP.(xs)

"""
    int_from_indices(idxs; N)

Return an Int bitmask of length N with ones at the 0-based positions in `idxs`.
"""
function int_from_indices(idxs::AbstractVector{<:Integer}; N::Integer)
    n::UInt = 0x0
    for b in idxs
        n |= UInt(1) << UInt(b)
    end
    # mask to N bits is implicit when used; return Int
    return Int(n)
end

"""
    ground_occupations(ε, M)

Return a Vector{MP} of EBVs xᵢ ∈ {0,1} at g=0 by filling the M lowest single-particle levels.
"""
function ground_occupations(ε::AbstractVector, M::Integer)
    idx = sortperm(ε)
    x = zeros(MP, length(ε))
    for k in 1:M
        x[idx[k]] = one(MP)
    end
    return x
end

end # module
