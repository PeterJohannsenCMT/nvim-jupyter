module ClaeysMatrices
export epsilon_matrix, residual!, jacobian!, matrix_element_c

using LinearAlgebra
using ..Common: tobig
const MP = BigFloat

"""
    epsilon_matrix(ε; diag_sign=-1)

Construct E with
E[i,j] = 1/(ε[i] - ε[j]) for i≠j,
E[i,i] = -∑_{k≠i} 1/(ε[i]-ε[k])  (diag_sign = -1 by default).
"""
function epsilon_matrix(ε::AbstractVector{<:Real}; diag_sign::Integer=-1)
    N = length(ε)
    E = zeros(MP, N, N)
    for i in 1:N
        s = MP(0)
        for k in 1:N
            if k != i
                val = inv(MP(ε[i]) - MP(ε[k]))
                E[i,k] = val
                s += val
            end
        end
        E[i,i] = diag_sign * s
    end
    return E
end

"""
    residual!(r, x, g, E)

EBV residual per your equation:
    rᵢ = xᵢ^2 - xᵢ - g * ∑_{j≠i} (xⱼ - xᵢ)/(εⱼ - εᵢ)
Using E, this is r = x.^2 - x + g * (E * x).
"""
function residual!(r::AbstractVector, x::AbstractVector, g, E::AbstractMatrix)
    @inbounds @views begin
        r .= x .* x .- x .+ MP(g) .* (E * x)
    end
    return r
end

"""
    jacobian!(J, x, g, E)

From the same EBV equation, ∂r/∂x = Diag(2x - 1) + g * E.
"""
function jacobian!(J::AbstractMatrix, x::AbstractVector, g, E::AbstractMatrix)
    N = length(x)
    @inbounds begin
        J .= MP(g) .* E
        for i in 1:N
            J[i,i] += 2*MP(x[i]) - one(MP)
        end
    end
    return J
end

"""
    matrix_element_c(xA, xB, E, g)

Slavnov-like determinant ratio using the EBV Jacobian:
    ⟨A|c|B⟩ ∝ det(J(xA, xB)) / sqrt(|det(J(xA, xA))*det(J(xB, xB))|).
Here we take the cross-J to be Diag(2xA - 1) + g*E, consistent with the
linearization around state A (adjust if you use a different convention).
"""
function matrix_element_c(xA::AbstractVector, xB::AbstractVector, E::AbstractMatrix, g)
    N = length(xA)
    JAA = MP(g).*E + Diagonal(@. (2*MP(xA) - 1))
    JBB = MP(g).*E + Diagonal(@. (2*MP(xB) - 1))
    JAB = MP(g).*E + Diagonal(@. (2*MP(xA) - 1))
    num = det(JAB)
    den = sqrt(abs(det(JAA) * det(JBB)))
    return num / den
end

end # module
