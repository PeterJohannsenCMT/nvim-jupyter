module Richardson
export Parameters, Solver, solve!, integrate!

using LinearAlgebra
using ..Common: ground_occupations
using ..ClaeysMatrices: epsilon_matrix
using ..Integration: NewtonOptions, newton!, integrate!
const MP = BigFloat

Base.@kwdef mutable struct Parameters
    newton::NewtonOptions = NewtonOptions()
end

mutable struct Solver
    ε::Vector{MP}
    M::Int
    x::Vector{MP}   # EBVs per level
    E::Matrix{MP}
    params::Parameters
end

function Solver(ε::AbstractVector, M::Integer; g0::Real=0.0, params::Parameters=Parameters())
    εb = MP.(ε)
    x0 = ground_occupations(εb, M)
    E = epsilon_matrix(εb)
    return Solver(εb, M, x0, E, params)
end

"""
    solve!(rg; g)

Refine EBVs at a single coupling g.
"""
function solve!(rg::Solver; g::Real)
    x = rg.x
    ok, it = newton!(x, g, rg.E; opts=rg.params.newton)
    rg.x = x
    return ok, it
end

"""
    integrate!(rg; gpath, onstep)

Integrate EBVs along a g grid.
"""
function integrate!(rg::Solver; gpath::AbstractVector, onstep::Function=(g,x)->nothing)
    x = rg.x
    integrate!(x, rg.ε; gpath=gpath, opts=rg.params.newton, onstep=onstep)
    rg.x = x
    return x
end

end # module
