module LinearAlgebraExtras
export angle_between, svd_solve_or_pinv

using LinearAlgebra

function angle_between(a::AbstractVector, b::AbstractVector)
    na = norm(a); nb = norm(b)
    if na == 0 || nb == 0
        return zero(promote_type(eltype(a), eltype(b)))
    end
    c = clamp(real(dot(a,b)) / (na*nb), -one(real(eltype(na))), one(real(eltype(na))))
    return acos(c)
end

function svd_solve_or_pinv(A::AbstractMatrix, b::AbstractVector; atol=1e-30)
    U, S, V = svd(A)
    Sinv = Diagonal(map(s -> abs(s) > atol ? inv(s) : zero(s), S))
    return V * Sinv * U' * b
end

end # module
