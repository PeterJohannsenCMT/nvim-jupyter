module Integration
export NewtonOptions, newton!, integrate!

using LinearAlgebra
using ..LinearAlgebraExtras: svd_solve_or_pinv
using ..ClaeysMatrices: residual!, jacobian!
const MP = BigFloat

Base.@kwdef mutable struct NewtonOptions
    atol::Float64 = 1e-28       # residual tolerance
    dx_tol::Float64 = 1e-30     # step tolerance
    maxiter::Int = 100
    svd_atol::Float64 = 1e-40
end

"""
    newton!(x, g, E; opts)

In-place Newton to solve residual!(r,x,g,E)=0 with analytic Jacobian.
Returns (ok, iters).
"""
function newton!(x::AbstractVector, g, E::AbstractMatrix; opts::NewtonOptions=NewtonOptions())
    N = length(x)
    r = zeros(MP, N)
    J = zeros(MP, N, N)
    for it in 1:opts.maxiter
        residual!(r, x, g, E)
        rn = norm(r)
        if rn < opts.atol
            return true, it
        end
        jacobian!(J, x, g, E)
        dx = try
            J \ r
        catch
            svd_solve_or_pinv(J, r; atol=opts.svd_atol)
        end
        x .-= dx
        if norm(dx) < opts.dx_tol
            return true, it
        end
    end
    return false, opts.maxiter
end

"""
    integrate!(x, ε; gpath, opts, onstep)

Adaptive predictor-corrector along a monotonically increasing vector `gpath`.
Predictor: hold x constant; Corrector: Newton. Step-size control via retries.
"""
function integrate!(x::AbstractVector, ε::AbstractVector; gpath::AbstractVector, opts::NewtonOptions=NewtonOptions(), onstep::Function = (g,x)->nothing)
    E = epsilon_matrix(ε)
    x .= MP.(x)
    # Ensure initial x satisfies at least roughly at initial g
    g0 = first(gpath)
    ok, _ = newton!(x, g0, E; opts=opts)
    ok || @warn "Initial Newton did not fully converge at g=$(g0). Proceeding."

    last_good = copy(x)
    for k in 2:length(gpath)
        g_prev = gpath[k-1]; g = gpath[k]
        # Predictor: keep x frozen (forward Euler with zero slope)
        x_pred = copy(x)
        x .= x_pred
        ok, it = newton!(x, g, E; opts=opts)
        if !ok
            # retry once from last_good
            x .= last_good
            ok2, _ = newton!(x, g, E; opts=opts)
            ok2 || @warn "Newton failed at g=$(g)."
        end
        last_good .= x
        onstep(g, x)
    end
    return x
end

end # module
