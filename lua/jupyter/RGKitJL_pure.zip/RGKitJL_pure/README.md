# RGKit.jl (pure Julia)

A pure-Julia implementation of the EBV (eigenvalue-based variable) Richardson–Gaudin
solver with analytic Jacobian and an adaptive path integrator in `g`. No Python.

## Key equations implemented

We use the EBV form (consistent with your notes):
```
r_i(x; g) = x_i^2 - x_i - g * sum_{j≠i} (x_j - x_i)/(ε_j - ε_i) = 0.
```
Defining `E` with `E[i,j]=1/(ε_i-ε_j)` for `i≠j` and
`E[i,i] = -∑_{k≠i} 1/(ε_i - ε_k)`, we have
```
r(x; g) = x.^2 - x + g * (E * x)
J(x; g) = ∂r/∂x = Diagonal(2x - 1) + g * E.
```

## Modules

- `ClaeysMatrices`: `epsilon_matrix`, `residual!`, `jacobian!`, `matrix_element_c` (Slavnov-like ratio).
- `Integration`: `newton!` (analytic Jacobian) and `integrate!` (predictor-corrector).
- `Richardson`: `Solver` wrapper holding `ε`, `M`, `x`, `E`, `Parameters`.
- `Common`, `LinearAlgebraExtras`: helpers.

## Quick start

```julia
julia> ] activate .
julia> ] instantiate
julia> using RGKit, RGKit.Richardson

julia> ε = collect(range(-1,1; length=12));
julia> rg = Solver(ε, 5);                 # fill 5 lowest levels at g=0

julia> ok, it = solve!(rg; g=0.0)         # Newton at g=0 (should be trivial)
(true, 1)

julia> gpath = collect(range(0.0, 1.0; length=50));
julia> integrate!(rg; gpath=gpath);        # track EBVs along g
```

## Notes

- If your internal convention differs by an overall scaling (e.g., `-g/2`), adapt it
in one place by rescaling `g` passed to `residual!`/`jacobian!`, or insert the factor in
`J(x; g)` and `r(x; g)` accordingly.

- The overlap `matrix_element_c` is provided in determinant-ratio form that matches the
Jacobians above; adjust if your cross-J definition differs.

- Exact diagonalisation and effective-H manager/state organiser are not included here
since your Python relied on external ManyBody constructs—add them natively if needed.
