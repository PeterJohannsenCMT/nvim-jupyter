module ExactDiagonalisation
export ExactDiagonaliser

using LinearAlgebra, SparseArrays, Arpack

mutable struct ExactDiagonaliser
    ε::Vector{Float64}
    N::Int
end

function ExactDiagonaliser(ε::AbstractVector{<:Real}, M::Integer)
    # M kept for API compatibility
    return ExactDiagonaliser(collect(float.(ε)), length(ε))
end

"""Construct interaction Hamiltonian H_int(g, t, U, εd, B). Fill per your Python definition."""
function Hint(ed::ExactDiagonaliser, g::Real, t::Real, U::Real, εd::Real, B::Real)
    # TODO: build sparse Hermitian matrix based on your ManyBodyPhysics layer.
    throw(ArgumentError("Hint not yet implemented – port your Python ManyBodyPhysics mapping here."))
end

"""Return lowest k eigenvalues using Arpack.eigs."""
function energy(ed::ExactDiagonaliser, g::Real, t::Real, U::Real, εd::Real, B::Real; nev::Int=6, which::AbstractString="SR")
    H = Hint(ed, g, t, U, εd, B)
    vals, vecs, nconv, niter, resid = eigs(H; nev=nev, which=which, ritzvec=false)
    return real(vals)
end

end # module
