module Integration
export NewtonOptions, newton_solver, predict_lambdas

using LinearAlgebra
using ..LinearAlgebraExtras: svd_solve_or_pinv
const MP = BigFloat

Base.@kwdef mutable struct NewtonOptions
    atol::Float64 = 1e-12          # residual tolerance
    dx_tol::Float64 = 1e-18        # step tolerance
    maxiter::Int = 100
    svd_atol::Float64 = 1e-30
end

"""Generic Newton solver over EBVs. Provide callbacks f(λ,g,Eps)->fval and J(λ,g,Eps)->Jac."""
function newton_solver(λ::AbstractVector, g, Eps::AbstractMatrix; f!, J!, opts::NewtonOptions=NewtonOptions())
    λv = MP.(λ)
    for it in 1:opts.maxiter
        fval = f!(λv, g, Eps)
        if norm(fval) < opts.atol
            return λv, true, it
        end
        Jmat = J!(λv, g, Eps)
        try
            dx = Jmat \ fval
        catch
            dx = svd_solve_or_pinv(Jmat, fval; atol=opts.svd_atol)
        end
        λnew = λv .- dx
        if norm(dx) < opts.dx_tol
            return λnew, true, it
        end
        λv = λnew
    end
    return λv, false, opts.maxiter
end

"""Lightweight linear predictor using J0 at g and RHS from EBV equations; refine with newton_solver."""
function predict_lambdas(λ::AbstractVector, Eps::AbstractMatrix, g::Real, dg::Real; f!, J!, opts::NewtonOptions=NewtonOptions())
    λ0 = MP.(λ)
    J0 = J!(λ0, g, Eps)
    # Placeholder: forward Euler prediction
    rhs = f!(λ0, g, Eps)
    dλ = svd_solve_or_pinv(J0, rhs; atol=opts.svd_atol)
    λpred = λ0 .+ MP(dg) .* dλ
    return λpred
end

end # module
