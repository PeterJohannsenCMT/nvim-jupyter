module HeffManager
# TODO: Translate HeffManager.py into a Julia struct/module here.
end
