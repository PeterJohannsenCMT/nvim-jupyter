module LinearAlgebraExtras
export angle_between, solve_from_lu, svd_solve_or_pinv, compute_residual

using LinearAlgebra

"""Angle between two vectors (in radians)."""
function angle_between(a::AbstractVector, b::AbstractVector)
    na = norm(a); nb = norm(b)
    if na == 0 || nb == 0
        return zero(eltype(a))
    end
    c = clamp(real(dot(a,b)) / (na*nb), -one(real(eltype(a))), one(real(eltype(a))))
    return acos(c)
end

"""Compute residual norm ||Ax - b|| given LU of A."""
function compute_residual(F::LU, b::AbstractVector, x::AbstractVector)
    r = F\(F.U * (F.L * (F.P*b))) # not actually used; provide explicit A?
    # Better: reconstruct A approximately
    A = (Matrix(F.P)') * (LowerTriangular(F.L)) * (UpperTriangular(F.U))
    return norm(A*x - b)
end

"""Solve Ax=b using precomputed LU."""
function solve_from_lu(F::LU, b::AbstractVector; compute_error::Bool=false)
    x = F \ b
    return compute_error ? (x, norm(Matrix(F)\*x - b)) : x
end

"""SVD-based least-squares solve with fallback to pinv for near-singular systems."""
function svd_solve_or_pinv(A::AbstractMatrix, b::AbstractVector; atol=1e-30)
    U, S, V = svd(A)
    # regularize tiny singular values
    Sinv = Diagonal(map(s -> abs(s) > atol ? inv(s) : zero(s), S))
    x = V * Sinv * U' * b
    return x
end

end # module
