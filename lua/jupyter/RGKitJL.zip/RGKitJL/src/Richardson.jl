module Richardson
export Parameters, Solver

using LinearAlgebra
using ..ClaeysMatrices: epsilon_matrix, J_matrix
using ..Integration: NewtonOptions, newton_solver, predict_lambdas
const MP = BigFloat

Base.@kwdef mutable struct Parameters
    lambda_tolerance::Float64 = 1e-18
    newton_iterations::Int = 100
    atol::Float64 = 1e-12
    svd_atol::Float64 = 1e-30
end

mutable struct Solver
    ε::Vector{MP}
    M::Int
    g::MP
    λ::Vector{MP}
    Eps::Matrix{MP}
    params::Parameters
end

function Solver(ε::AbstractVector, M::Integer; g::Real=0.0, params::Parameters=Parameters())
    εb = MP.(ε)
    Eps = epsilon_matrix(εb)
    λ0 = fill(MP(0), M)
    return Solver(εb, M, MP(g), λ0, Eps, params)
end

"""One Newton refinement step (requires you to pass correct f! and J!)."""
function refine!(rg::Solver; f!, J!)
    opts = NewtonOptions(atol=rg.params.atol, dx_tol=rg.params.lambda_tolerance,
                         maxiter=rg.params.newton_iterations, svd_atol=rg.params.svd_atol)
    λ, ok, it = newton_solver(rg.λ, rg.g, rg.Eps; f!=f!, J!=J!, opts=opts)
    rg.λ = λ
    return ok, it
end

end # module
