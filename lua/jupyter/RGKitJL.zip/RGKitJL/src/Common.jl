module Common
export elementwise, tobig, int_from_arr, generate_states

using LinearAlgebra
using Combinatorics

const MP = BigFloat

"""Broadcasted elementwise product that returns a Vector{MP}."""
function elementwise(A::AbstractVector, B::AbstractVector)
    @assert length(A) == length(B)
    return MP.(A) .* MP.(B)
end

"""Convert a number or array to BigFloat(s)."""
tobig(x) = MP(x)
tobig(xs::AbstractArray) = MP.(xs)

"""Return an integer bitmask from a list of 0-based indices."""
function int_from_arr(arr::AbstractVector{<:Integer})
    n::UInt = 0
    for b in arr
        n |= UInt(1) << UInt(b)
    end
    return Int(n)
end

"""
    generate_states(N, M)

Yield all length-N bitmasks (as Int) with exactly M ones. Order matches Python's combinations(range(N), M).
"""
function generate_states(N::Integer, M::Integer)
    for ones in combinations(0:N-1, M)
        bits = fill('0', N)
        for i in ones
            bits[Int(i)+1] = '1'
        end
        yield = parse(Int, String(bits); base=2)
        produce(yield)
    end
end

end # module
