module RGKit
export setprecision!, MP, @bf, elementwise, int_from_arr, generate_states,
       angle_between, solve_from_lu, svd_solve_or_pinv,
       epsilon_matrix, J_matrix,
       NewtonOptions, newton_solver,
       Parameters, Solver

using LinearAlgebra
using SparseArrays
using Printf
using Logging
using ProgressMeter
using Statistics
using Random
using Combinatorics

# High-precision helpers -------------------------------------------------------
# Use BigFloat by default (you can switch to Float64 for speed).
const MP = BigFloat

"""Set global BigFloat precision in bits."""
function setprecision!(bits::Integer)
    setprecision(bits)
end

"""Macro to construct BigFloat literals conveniently.""" 
macro bf(x)
    :(parse(BigFloat, $(string(x))))
end

include("Common.jl")
include("Helpers.jl")
include("LinearAlgebraExtras.jl")
include("ClaeysMatrices.jl")
include("Integration.jl")
include("Richardson.jl")
include("ExactDiagonalisation.jl")
include("HeffManager.jl")
include("StateOrganizer.jl")

end # module
