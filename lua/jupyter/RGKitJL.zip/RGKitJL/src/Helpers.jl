module Helpers
export AutoLog, Timing, flatten

using Dates

"""Minimal structured logger mirroring Python dataclass used in the project."""
mutable struct AutoLog
    buffer::Vector{Pair{String,Any}}
    AutoLog() = new(Pair{String,Any}[])
end

function Base.setindex!(al::AutoLog, v, k::AbstractString)
    push!(al.buffer, k=>v)
end

function Base.getindex(al::AutoLog, k::AbstractString)
    for (kk, vv) in al.buffer
        kk == k && return vv
    end
    return nothing
end

Base.show(io::IO, al::AutoLog) = print(io, Dict(al.buffer...))

"""Lightweight timing helper."""
mutable struct Timing
    t0::DateTime
    Timing() = new(now())
end

elapsed(s::Timing) = now() - s.t0

"""Flatten a nested Pair/Dict-like structure using dot-notation keys."""
function flatten(prefix::AbstractString, m, out::Dict{String,Any})
    for (k, v) in m
        key = isempty(prefix) ? string(k) : string(prefix, ".", k)
        if v isa AbstractDict || v isa Vector{<:Pair}
            flatten(key, v, out)
        else
            out[key] = v
        end
    end
    return out
end

end # module
