using Test
using RGKit

@testset "Scaffold smoke tests" begin
    using RGKit.Common
    @test Common.int_from_arr([0,2,4]) == parse(Int, "10101"; base=2)
    using RGKit.ClaeysMatrices
    ε = [0.1, 0.2, 0.4]
    E = epsilon_matrix(ε)
    @test size(E) == (3,3)
    using RGKit.LinearAlgebraExtras
    a = [1.0,2.0,3.0]; b = [1.0,0.0,1.0]
    θ = angle_between(a,b)
    @test 0.0 <= θ <= π
end
