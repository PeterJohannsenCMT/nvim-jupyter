# RGKit.jl (scaffold)

This is a first-pass Julia translation scaffold of your Python project. It preserves the module structure and public API while leaving domain-specific formulas as TODOs where the original sources were redacted.

## Layout
- `src/Common.jl`: utilities (`elementwise`, `int_from_arr`, `generate_states`).
- `src/Helpers.jl`: `AutoLog`, `Timing`, `flatten`.
- `src/LinearAlgebraExtras.jl`: LU/SVD helpers, `angle_between`.
- `src/ClaeysMatrices.jl`: **PLACEHOLDER** implementations of `epsilon_matrix`, `J_matrix`, and `matrix_element_c`. Fill with your exact Claeys/EBV formulas (note your own -g/2 convention).
- `src/Integration.jl`: Newton/predictor-corrector scaffolding (`newton_solver`, `predict_lambdas`).
- `src/Richardson.jl`: `Parameters` and `Solver` wrapper.
- `src/ExactDiagonalisation.jl`: ED scaffold using Arpack.jl (**requires you to port `Hint`**).
- `src/HeffManager.jl`, `src/StateOrganizer.jl`: stubs.

## Usage
```julia
julia> ] activate .
julia> ] test
```

## Next steps
1. Replace the placeholder math in `ClaeysMatrices.jl` with your exact formulas.
2. Implement `Hint` in `ExactDiagonalisation.jl` to mirror your Python `ManyBodyPhysics` coupling.
3. Flesh out `HeffManager` and `StateOrganizer`.

